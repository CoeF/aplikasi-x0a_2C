@extends('layouts.header')
@section('title','Mahasiswa')
@section('content')
<div class="content-wrapper">
  <div class="row">
    <div class="col-md-12 stretch-card">
      <div class="card">
        <div class="card-body">
          <p style="text-align: center;" class="card-title">Data Mahasiswa</p>
          <div class="d-sm-flex justify-content-center">
            <form class="form-inline my-2 my-lg-0" action="" method="POST">
              @csrf
               <!-- <input class="form-control mr-sm-12" type="text" name="cari" placeholder="Cari Supplier" id="cari" aria-label="cari" value="{{old('cari')}}">-->
              <!-- <button class="btn btn-outline-success my-12 my-sm-12" type="submit">Cari</button>-->
            </form>
          </div>
          <div class="table-responsive">
            <table id="recent-purchases-listing" class="table">
              <thead class="thead-light">
                <tr align="center">
                  <th scope="col">#</th>
                  <!-- <th scope="col">ID Supplier</th> -->
				  <th scope="col">NIM</th>
                  <th scope="col">Nama</th>
				  <th scope="col">ID Prodi</th>
				  <th scope="col">Photos</th>
                  
                </tr>
              </thead>
              <tbody>
                @forelse ($ndata as $sp)
                <tr>
                  <td>{{$loop->iteration }}</td>
                  <!-- <td>{{$sp->id_jns}}</td> -->
				  <td>{{$sp->nim}}</td>
                  <td>{{$sp->nama}}</td>
				  <td>{{$sp->mprodi->nama_prodi}}</td>
				  <td> <img src="http://localhost:8000/style/images/{{$sp->photos}}" width="50px" height="50px"> </td>
                </tr>
                @empty
                <tr>
                  <td colspan="7" style="text-align: center">Tidak Ada Data </td>
                </tr>
                @endforelse
              </tbody>
            </table>
            
             <!-- <a href="/jenisbarang/create" type="button" class="btn btn-outline-primary">Tambah Jenis Barang</a>-->
            <hr>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection