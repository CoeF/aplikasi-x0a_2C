@extends('layouts.header')
@section('title','Prodi')
@section('content')
<div class="content-wrapper">
  <div class="row">
    <div class="col-md-12 stretch-card">
      <div class="card">
        <div class="card-body">
          <p style="text-align: center;" class="card-title">Data Prodi</p>
          <div class="d-sm-flex justify-content-center">
            <form class="form-inline my-2 my-lg-0" action="/jenisbarang/search" method="POST">
              @csrf
              <!--<input class="form-control mr-sm-12" type="text" name="cari" placeholder="Cari Supplier" id="cari" aria-label="cari" value="{{old('cari')}}">-->
              <!--<button class="btn btn-outline-success my-12 my-sm-12" type="submit">Cari</button>-->
            </form>
          </div>
          <!-- <a href="/jenisbarang/exportpdf" type="button" id="PdfData" class="btn mr-2 mb-2 btn-danger">
            <i class="fa fa-download fa-w-20"></i>
            Export PDF
          </a>
          <a href="/jenisbarang/exportexcel" type="button" id="PdfData" class="btn mr-2 mb-2 btn-success">
            <i class="fa fa-download fa-w-20"></i>
            Export Excel
          </a> -->
          <div class="table-responsive">
            <table id="recent-purchases-listing" class="table">
              <thead class="thead-light">
                <tr align="center">
                  <!--<th scope="col">#</th>-->
                  <!-- <th scope="col">ID Supplier</th> -->
                  <th scope="col">ID Prodi</th>
                  <th scope="col">Nama Prodi</th>
                </tr>
              </thead>
              <tbody>
                @forelse ($ndata as $sp)
                <tr>
                 <!-- <td>{{$loop->iteration}}</td>-->
                  <!-- <td>{{$sp->id_jns}}</td> -->
                  <td>{{$sp->id_prodi}}</td>
				  <td>{{$sp->nama_prodi}}</td>
                </tr>
                @empty
                <tr>
                  <td colspan="7" style="text-align: center">Tidak Ada Data </td>
                </tr>
                @endforelse
              </tbody>
            </table>
            <hr>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection