/*
SQLyog Ultimate
MySQL - 10.4.14-MariaDB : Database - kampus2
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`kampus2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `kampus2`;

/*Table structure for table `mahasiswa` */

CREATE TABLE `mahasiswa` (
  `nim` varchar(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `photos` varchar(20) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`nim`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `mahasiswa` */

insert  into `mahasiswa`(`nim`,`nama`,`id_prodi`,`photos`,`alamat`,`created_at`,`updated_at`) values 
('193173012','Qowwim \'Ubaidillah',1,'qowwim.jpg','Kediri',NULL,NULL),
('193173013','M Durisa E.A',2,'durisa.jpg','Malang',NULL,NULL),
('193173014','M Dimas Khulil A',3,'dimas.jpg','Tulungagung',NULL,NULL),
('193173015','Abdul Rahman',4,'abdul.jpg','Surabaya',NULL,NULL),
('193173016','Fika Aulia',5,'fika.jpg','Cirebon',NULL,NULL),
('193173017','Dhima Astuti',1,'dhima.jpg','Jakarta',NULL,NULL),
('193173018','Vina Sila',2,'vina.jpg','Sulawesi',NULL,NULL);

/*Table structure for table `prodi` */

CREATE TABLE `prodi` (
  `id_prodi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_prodi` varchar(30) NOT NULL,
  PRIMARY KEY (`id_prodi`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

/*Data for the table `prodi` */

insert  into `prodi`(`id_prodi`,`nama_prodi`) values 
(1,'Manajemen Informatika'),
(2,'Akuntansi'),
(3,'Permesinan'),
(4,'Teknik Elektro'),
(5,'Keuangan Publik'),
(6,'Teknik Manufaktur');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
