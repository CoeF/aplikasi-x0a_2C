<?php

namespace App\Http\Controllers;

use App\Models\ProdiModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
class Prodi extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = ProdiModel::all();
        return view('prodi.index', ['ndata' => $data]);
		$response[“prodi”] = $prodi;
		return response()->json($response);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Tampil View form Tambah data jenisbarang
        return view('jenisbarang.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Memanggil model, query simpan data
        $data = new JenisModel;
        //Memvalidasi Data
        $this->validate($request,[
        'id_jns' => 'required|unique:tabel_jenis_barang',
        ]);
        //sebelah kiri nama di DB dan sebelah kanan nama di form (view)
        $data->id_sup = $request->id_sup;
        $data->nama = $request->nama;
        
        $data ->save();

        //Redirect setelah berhasil simpan data
        return redirect('/jenisbarang')->with('success','Data Berhasil di Tambahkan !');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\jenisbarang  $jenisbarang
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //memanggil model, query
        $data = JenisModel::where('id_sup', $id)->get();

        //memanggil model nilai, query dengan kondisi where
        // $data = JenisModel::where('nim', $id)->first();

        //memanggil relasi table, dgn cara memanggil method
        // $datanli = $data->ambilnilai()->paginate(3);
        // return view('jenisbarang.show', ['datamhs' => $datamhs,
        //                                 'datanli' => $datanli]);
        return view('jenisbarang.show', ['data' => $data]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\jenisbarang  $jenisbarang
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Method model, query dengan kondisi where
        $data=JenisModel::where('id_sup', $id)->get();
        return view ('jenisbarang.edit', ['data'=> $data]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\jenisbarang  $jenisbarang
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Memanggil model, query dengan kondisi where first

        $data=JenisModel::where('id_sup', $id)->first();
        $data->id_sup = $request->id_sup;
        $data->nama = $request->nama;
        $data->alamat = $request->alamat;
        $data->kota = $request->kota;
        $data->telp = $request->telp;
        $data ->save();

        //Redirect setelah berhasil simpan data
        return redirect('/jenisbarang/index')->with('success','Data Berhasil di Update !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\jenisbarang  $jenisbarang
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data=JenisModel::where('id_sup', $id)->first();
        $data->delete();

        //Redirect setelah berhasil simpan data
        return redirect('/jenisbarang/index')->with('success','Data Berhasil di Hapus !');
    }
    public function search(Request $request){
        //Menangkap data dari pencarian
        $cari = $request->cari;
        //Query Data dari table jenisbarang
        $data = JenisModel::where('nama', 'LIKE', "%".$cari."%")->paginate();
        //Session untuk tampilan old pada input pencarian
        session()->flashInput($request->input());
        //Mengirim data ke View
        return view('jenisbarang.index',['ndata' => $data]);
    }
    public function printpdf()
    {
        //Ambil data Supplier
        $data = JenisModel::all();
        //Di tampilkan ke dalam file cetak PDF dalam bentuk landscape
        $pdf = PDF::loadview('jenisbarang.cetakpdf',['ndata' => $data])->setPaper('A4','landscape');
        //File Download
        return $pdf->download('jenisbarang.pdf');
    }
    public function printexcel()
    {
        return Excel::download(new ExportSupplier, 'jenisbarang.xlsx');
    }

}
