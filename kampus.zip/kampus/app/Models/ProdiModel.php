<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProdiModel extends Model
{
    use HasFactory;
    //nama tabel
    protected $table = 'prodi';
    //default primary ky
    protected $primarykey = 'id_prodi';

    
    public function wali()
    {
        return $this->hasOne('App\Models\DosenModel', 'nidn', 'dosen_wali');
    }

    public function ambilnilai()
    {
        return $this->hasMany('App\Models\NilaiModel', 'nim_dinilai', 'nim');
    }
}
